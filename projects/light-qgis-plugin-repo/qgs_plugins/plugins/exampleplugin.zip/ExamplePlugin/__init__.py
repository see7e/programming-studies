# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ExamplePlugin
                                 A QGIS plugin
 An example plugin shipped with phpQGISrepository
                             -------------------
        begin                : 2016-03-08
        copyright            : (C) 2016 by Michel Stuyts
        email                : michel@stuyts.xyz
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load ExamplePlugin class from file ExamplePlugin.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .example_plugin import ExamplePlugin
    return ExamplePlugin(iface)
